//
//  Identifier.swift
//  Project5
//
//  Created by Mohammed Mujadib on 25/12/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation

struct Identifiers {
    struct PinIdentifier {
        static let pinID = "pinID"
    }
    struct SegueIdentifier {
        static let toPhotoAlbumVC = "toPhotoAlbumVC"
    }
    
    struct CellsIdentifier {
        static let photoCell = "photoCell"
    }
}

