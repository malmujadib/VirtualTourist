//
//  ViewController.swift
//  Project5
//
//  Created by Mohammed Mujadib on 25/12/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

