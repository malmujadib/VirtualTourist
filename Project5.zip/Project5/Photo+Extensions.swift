//
//  Photo+Extensions.swift
//  Project5
//
//  Created by Mohammed Mujadib on 25/12/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import UIKit
import CoreData
extension Photo{
    public override func awakeFromInsert() {
        super.awakeFromInsert()
        creationDate = Date()
    }
    func getImage() -> UIImage? {
        if image != nil {
           return UIImage(data: image! as Data)
        } else {
            return nil
        }
    }
}

