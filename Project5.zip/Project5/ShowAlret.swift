//
//  ShowAlret.swift
//  Project5
//
//  Created by Mohammed Mujadib on 25/12/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import Foundation
import UIKit
struct ShowAlert {
    static func showAlert(title: String, message: String, vc: UIViewController) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        DispatchQueue.main.async {
            vc.present(alertController, animated: true, completion: nil)
        }
    }
}

enum Helper {
    static func displayAlertMessage(_ viewController: UIViewController, _ title: String, _ message: String){
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Dissmiss", style: .default, handler: nil))
            viewController.present(alert,animated: true, completion: nil)
        }
    }
}
