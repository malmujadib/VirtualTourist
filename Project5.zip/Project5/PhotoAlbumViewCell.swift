//
//  PhotoAlbumViewCell.swift
//  Project5
//
//  Created by Mohammed Mujadib on 25/12/1441 AH.
//  Copyright © 1441 mohammed al mujadib. All rights reserved.
//

import UIKit
import CoreData
import Kingfisher

class PhotoAlbumViewCell: UICollectionViewCell {
    @IBOutlet var photoAlbum: UIImageView!
    var flickerImage: UIImage!
    
    func configureCell(photo: Photo) {

        if let image = photo.getImage() {
            print("Load Image from Core Data")
            photoAlbum.image = image
        } else {

            guard let photourl = photo.url else { return }
            guard let url = URL(string: photourl) else { return }
            photoAlbum.kf.indicatorType = .activity
            print("load data from flicker")
            photoAlbum.kf.setImage(with: url)
                }
            }
        }
